import BrandMark from "../components/ui/BrandMark";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

function Sidebar({ items = [], onNavigate }) {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = async () => {
        onNavigate?.();
        navigate("/", { replace: true });
        await logout();
    };

    const isAdmin = user?.role === "admin";
    const isStaff = user?.role === "staff";

    return (
        <aside className={`dashboard-sidebar ${isAdmin ? "sidebar-admin" : ""} ${isStaff ? "sidebar-staff" : ""}`}>
            <div className="sidebar-header">
                <BrandMark className="sidebar-logo" />

                <div>
                    <h2>Barangay</h2>
                    <span>Document System</span>
                </div>
            </div>

            <div className="sidebar-user">
                <strong>{user?.first_name || user?.username || "User"}</strong>

                <span>{user?.role || "user"}</span>
            </div>

            <nav className="sidebar-navigation">
                {items.map((item) => (
                    <NavLink
                        key={item.to}
                        to={item.to}
                        onClick={onNavigate}
                        className={({ isActive }) =>
                            `sidebar-link ${isActive ? "active" : ""}`
                        }
                    >
                        {item.icon && (
                            <span className="sidebar-link-icon">
                                <i className={`bi ${item.icon}`} aria-hidden="true" />
                            </span>
                        )}

                        <span>{item.label}</span>
                    </NavLink>
                ))}
            </nav>

            <div className="sidebar-footer">
                <button
                    type="button"
                    className="sidebar-logout"
                    onClick={handleLogout}
                >
                    <i className="bi bi-box-arrow-right" aria-hidden="true" />
                    Logout
                </button>
            </div>
        </aside>
    );
}

export default Sidebar;
