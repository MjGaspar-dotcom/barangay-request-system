export default function BrandMark({
    src,
    className = "",
    alt = "Barangay logo",
}) {
    if (src) {
        return (
            <img
                className={`brand-mark ${className}`.trim()}
                src={src}
                alt={alt}
            />
        );
    }

    return (
        <span className={`brand-mark ${className}`.trim()} aria-hidden="true">
            B
        </span>
    );
}
