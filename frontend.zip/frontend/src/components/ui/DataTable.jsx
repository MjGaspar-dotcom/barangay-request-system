import Table from "react-bootstrap/Table";
/** Props: children, className, responsive, striped, bordered, hover, size. Wraps a Bootstrap Table in the shared horizontal-scroll container. */
export default function DataTable({
    children,
    className = "",
    responsive = true,
    ...props
}) {
    return (
        <div className="table-scroll">
            {responsive ? (
                <Table className={`data-table ${className}`.trim()} {...props}>
                    {children}
                </Table>
            ) : (
                <Table className={`data-table ${className}`.trim()} {...props}>
                    {children}
                </Table>
            )}
        </div>
    );
}
