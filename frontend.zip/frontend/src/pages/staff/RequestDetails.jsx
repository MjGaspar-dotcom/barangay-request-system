import { useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import { useNavigate, useParams } from "react-router-dom";
import api from "../../services/api";
import ConfirmDialog from "../../components/ui/ConfirmDialog";
import StatusBadge from "../../components/ui/StatusBadge";

function StaffRequestDetails() {
    const { type, requestId } = useParams();
    const navigate = useNavigate();

    const [request, setRequest] = useState(null);
    const [requestType, setRequestType] = useState(type || "registered");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [remarks, setRemarks] = useState("");
    const [submitting, setSubmitting] = useState(false);
    const [confirmation, setConfirmation] = useState(null);
    const [actionMessage, setActionMessage] = useState("");

    const fetchRequest = async () => {
        setLoading(true);
        setError("");

        try {
            let primaryEndpoint = `/barangay-requests/${requestId}`;
            if (type === "guest") {
                primaryEndpoint = `/guest-requests/${requestId}`;
            }

            let response;
            try {
                response = await api.get(primaryEndpoint);
                setRequestType(type || "registered");
            } catch (err) {
                // Fallback attempt if type was omitted in route
                if (!type && err.response?.status === 404) {
                    response = await api.get(`/guest-requests/${requestId}`);
                    setRequestType("guest");
                } else {
                    throw err;
                }
            }

            const data = response.data.data;
            setRequest(data);
            setRemarks(data.remarks || "");
        } catch (err) {
            console.error(err);
            if (err.response?.status === 403) {
                setError("You are not authorized to view this request.");
            } else if (err.response?.status === 404) {
                setError("Request not found.");
            } else {
                setError("Failed to load request details.");
            }
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchRequest();
    }, [type, requestId]);

    const handleStatusUpdate = (newStatus) => {
        setConfirmation({
            title: "Confirm status change",
            message: `Change status to “${newStatus}”?`,
            confirmLabel: `Change to ${newStatus}`,
            variant: newStatus === "Rejected" ? "danger" : "primary",
            action: () => performStatusUpdate(newStatus),
        });
    };

    const performStatusUpdate = async (newStatus) => {
        const endpoint = requestType === "guest" ? `/guest-requests/${requestId}` : `/barangay-requests/${requestId}`;
        setActionMessage("");
        setSubmitting(true);
        try {
            await api.put(endpoint, {
                status: newStatus,
                remarks: remarks || null,
            });
            setActionMessage(`Status updated to ${newStatus}.`);
            fetchRequest();
        } catch (err) {
            console.error("Failed to update status:", err);
            const msg = err.response?.data?.message || "Failed to update status.";
            setActionMessage(msg);
        } finally {
            setSubmitting(false);
        }
    };

    const handleDelete = () => {
        setConfirmation({
            title: "Delete request?",
            message: `Delete request ${request.tracking_number || `#${requestId}`}? This cannot be undone.`,
            confirmLabel: "Delete request",
            variant: "danger",
            action: performDelete,
        });
    };

    const performDelete = async () => {
        const endpoint = requestType === "guest" ? `/guest-requests/${requestId}` : `/barangay-requests/${requestId}`;
        setActionMessage("");
        try {
            await api.delete(endpoint);
            navigate("/staff/dashboard");
        } catch (err) {
            console.error("Failed to delete request:", err);
            const msg = err.response?.data?.message || "Failed to delete request.";
            setActionMessage(msg);
        }
    };

    if (loading) {
        return <div className="page-loading"><div className="spinner-border text-success" role="status"><span className="visually-hidden">Loading...</span></div><p>Loading request details...</p></div>;
    }

    if (error) {
        return (
            <div className="alert alert-danger detail-error-state" role="alert">
                <p>{error}</p>
                <Button className="btn btn-outline-secondary" onClick={() => navigate("/staff/dashboard")}>
                    Back to Dashboard
                </Button>
            </div>
        );
    }

    if (!request) return null;

    const isGuest = requestType === "guest";

    return (
        <main className="staff-request-details admin-dashboard staff-request-details-page">
            <div className="container-fluid">
            {actionMessage && <div className="alert alert-info" role="status">{actionMessage}</div>}
            <header className="dashboard-page-header page-header-row">
                <div><span className="section-label">REQUEST DETAILS</span><h1>{request.tracking_number || "Request Details"}</h1><p>{isGuest ? "Guest document request" : "Registered resident document request"}</p></div>
                <StatusBadge status={request.status} />
            </header>
            <div className="row g-4">
            <section className="col-12"><div className="admin-form-card detail-card">
            <h3 className="form-section-title">Request Information</h3>
            <div className="detail-grid">
                <div><span className="detail-label">Tracking Number</span><span className="detail-value">{request.tracking_number}</span></div>
                <div><span className="detail-label">Request Type</span><span className="detail-value">{isGuest ? "Guest Request" : "Registered Resident Request"}</span></div>
                <div><span className="detail-label">Document</span><span className="detail-value">{request.document_type?.document_name || "Unknown"}</span></div>
                <div><span className="detail-label">Status</span><span className="detail-value"><StatusBadge status={request.status} /></span></div>
                <div><span className="detail-label">Purpose</span><span className="detail-value">{request.purpose || "—"}</span></div>
            </div>
            </div></section>
            <section className="col-12"><div className="admin-form-card detail-card">
            <h3 className="form-section-title">Requester Details</h3>
            <div className="detail-grid">
            {!isGuest && request.user && <>
                <div><span className="detail-label">Name</span><span className="detail-value">{request.user.first_name} {request.user.last_name}</span></div>
                <div><span className="detail-label">Email</span><span className="detail-value">{request.user.email}</span></div>
                <div><span className="detail-label">Contact</span><span className="detail-value">{request.user.contact_number || "N/A"}</span></div>
            </>}
            {isGuest && <>
                <div><span className="detail-label">Name</span><span className="detail-value">{request.first_name} {request.middle_name ? `${request.middle_name} ` : ""}{request.last_name}</span></div>
                <div><span className="detail-label">Birth Date</span><span className="detail-value">{request.birth_date || "—"}</span></div>
                <div><span className="detail-label">Gender</span><span className="detail-value">{request.gender || "—"}</span></div>
                <div><span className="detail-label">Civil Status</span><span className="detail-value">{request.civil_status || "—"}</span></div>
                <div><span className="detail-label">Address</span><span className="detail-value">{request.address || "—"}</span></div>
                <div><span className="detail-label">Contact Number</span><span className="detail-value">{request.contact_number || "—"}</span></div>
                <div><span className="detail-label">Email</span><span className="detail-value">{request.email || "N/A"}</span></div>
                <div><span className="detail-label">Valid ID Type</span><span className="detail-value">{request.valid_id_type || "—"}</span></div>
                {request.valid_id_image && <div><span className="detail-label">Valid ID Image</span><span className="detail-value"><a href={`http://127.0.0.1:8000/storage/${request.valid_id_image}`} target="_blank" rel="noreferrer">View Submitted ID</a></span></div>}
            </>}
            </div></div></section>
            <section className="col-12"><div className="admin-form-card detail-card">
            <h3 className="form-section-title">Timestamps & Remarks</h3>
            <div className="detail-grid">
                <div><span className="detail-label">Submitted</span><span className="detail-value">{new Date(request.created_at).toLocaleString()}</span></div>
                {request.approved_at && <div><span className="detail-label">Approved At</span><span className="detail-value">{new Date(request.approved_at).toLocaleString()}</span></div>}
                {request.ready_for_pickup_at && <div><span className="detail-label">Ready for Pickup At</span><span className="detail-value">{new Date(request.ready_for_pickup_at).toLocaleString()}</span></div>}
                {request.claimed_at && <div><span className="detail-label">Claimed/Completed At</span><span className="detail-value">{new Date(request.claimed_at).toLocaleString()}</span></div>}
            </div>
            <div className="detail-form-field">
                <label className="form-label fw-semibold"><strong>Remarks / Processing Notes:</strong></label>
                <textarea className="form-control detail-remarks" rows={3} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Enter optional remarks before changing status" />
            </div>
            </div></section>
            <section className="col-12"><div className="admin-form-card detail-card">
            <h3 className="form-section-title">Actions</h3>
            <div className="detail-action-footer">
            {request.status === "Pending" && <>
                <Button type="button" className="btn btn-success" disabled={submitting} onClick={() => handleStatusUpdate("Approved")}>Approve</Button>
                <Button type="button" className="btn btn-outline-danger" disabled={submitting} onClick={() => handleStatusUpdate("Rejected")}>Reject</Button>
            </>}
            {request.status === "Approved" && <Button type="button" className="btn btn-success" disabled={submitting} onClick={() => handleStatusUpdate("Processing")}>Start Processing</Button>}
            {request.status === "Processing" && <Button type="button" className="btn btn-success" disabled={submitting} onClick={() => handleStatusUpdate("Ready for Pickup")}>Ready for Pickup</Button>}
            {request.status === "Ready for Pickup" && <Button type="button" className="btn btn-success" disabled={submitting} onClick={() => handleStatusUpdate("Completed")}>Mark Completed</Button>}
            <Button type="button" className="btn btn-outline-danger" disabled={submitting} onClick={handleDelete}>Delete Request</Button>
            </div></div></section></div>
            <Button className="btn btn-outline-secondary mt-4" onClick={() => navigate("/staff/dashboard")}>Back to Dashboard</Button>
            </div>
            <ConfirmDialog isOpen={Boolean(confirmation)} onClose={() => setConfirmation(null)} onConfirm={() => { const action = confirmation?.action; setConfirmation(null); if (action) action(); }} title={confirmation?.title} confirmLabel={confirmation?.confirmLabel} variant={confirmation?.variant}>{confirmation?.message}</ConfirmDialog>
        </main>
    );
}

export default StaffRequestDetails;
