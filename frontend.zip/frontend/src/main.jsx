import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import { AuthProvider } from "./contexts/AuthProvider";
import ErrorBoundary from "./components/ErrorBoundary";

import "./assets/styles/tokens.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "./assets/styles/theme.css";
import "./assets/styles/global.css";
import "./assets/styles/navbar.css";
import "./assets/styles/footer.css";

import "bootstrap-icons/font/bootstrap-icons.css";

import App from "./App";

createRoot(document.getElementById("root")).render(
    <StrictMode>
        <ErrorBoundary>
            <AuthProvider>
                <App />
            </AuthProvider>
        </ErrorBoundary>
    </StrictMode>,
);
