# Frontend styling map

- **Tokens (`tokens.css`)**: source values for colors, spacing, radii, shadows, and type scale. Add or change design values here first.
- **Bootstrap bridge (`theme.css`)**: maps tokens to Bootstrap 5.3 CSS variables and defines primary/outline button and focus variables. Role overrides live under `.portal-staff-workspace` and `.portal-admin-workspace`.
- **Global (`global.css`)**: resets, site-wide layout primitives, shared utility/component styles, focus treatment, and responsive shared patterns.
- **Page-scoped CSS**: styles unique to one page must be nested under that page's root class; preserve existing class names used elsewhere.
- **Shared UI (`src/components/ui/`)**: reusable React components and their semantic markup; use these when a replacement is behavior-preserving.
- **React Bootstrap**: import components by name from `react-bootstrap/*`. Do not import Bootstrap's JavaScript bundle.
- **Inline styles**: no inline styles except CSS custom properties for dynamic values.
- **Specificity**: no `!important` without a comment explaining why it is unavoidable.
- Keep API calls, routing, state transitions, and authentication behavior independent of visual refactors.
